import React, { Component } from 'react';

class QnaItem extends Component {
  render() {
    return (
      <div className="QnaItem">
      <li className="list-group-item">
      {this.props.question.q}
      </li>
      <li className="list-group-item list-group-item-success">
      {this.props.question.a}
      </li>
      <br />
      </div>
    );
  }
}

export default QnaItem;
